1. ansible folder is not part of Docker compose poc Project 
2. Docker Folder is also not part of Docker compose poc project 